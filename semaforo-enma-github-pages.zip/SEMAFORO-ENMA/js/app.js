const state = {
  datos: null,
  accionesFiltradas: [],
  filtros: {
    busqueda: '',
    estado: 'all',
    entidad: 'all',
    objecion: 'all'
  }
};

const estadosMap = {
  cumplida: { label: 'Cumplida', clase: 'ok' },
  cumplida_con_objecion: { label: 'Cumplida con objeción', clase: 'violet' },
  en_ejecucion: { label: 'En ejecución', clase: 'warn' },
  en_ejecucion_con_retraso: { label: 'En ejecución con retraso', clase: 'warn2' },
  no_iniciada: { label: 'No iniciada', clase: 'bad' },
  sin_informacion: { label: 'Sin información', clase: 'neutral' }
};

const resumenConfig = [
  { key: 'total', titulo: 'Total acciones', clase: 'total' },
  { key: 'cumplida', titulo: 'Cumplidas', clase: 'ok' },
  { key: 'cumplida_con_objecion', titulo: 'Cumplidas con objeción', clase: 'violet' },
  { key: 'en_ejecucion', titulo: 'En ejecución', clase: 'warn' },
  { key: 'en_ejecucion_con_retraso', titulo: 'En ejecución con retraso', clase: 'warn2' },
  { key: 'no_iniciada', titulo: 'No iniciadas', clase: 'bad' },
  { key: 'sin_informacion', titulo: 'Sin información', clase: 'neutral' }
];

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

function texto(value) {
  return value === null || value === undefined || value === '' ? '—' : String(value);
}

function year(value) {
  return value || '—';
}

function pct(value) {
  return value === null || value === undefined ? 'NDI' : `${value}%`;
}

function escapeHtml(str) {
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function normalizar(str) {
  return String(str || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

async function loadData() {
  const path = 'data/datos.json';
  try {
    const res = await fetch(path, { cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (fetchError) {
    const iframe = document.getElementById('datos-json-frame');
    try {
      return await leerJsonDesdeIframe(iframe);
    } catch (iframeError) {
      throw new Error(`Falló fetch (${fetchError.message}) y fallback iframe (${iframeError.message}).`);
    }
  }
}

function leerJsonDesdeIframe(iframe) {
  return new Promise((resolve, reject) => {
    let intentos = 0;
    const maxIntentos = 30;

    const parsear = () => {
      intentos += 1;
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        const raw = doc?.body?.innerText || doc?.documentElement?.textContent || '';
        if (raw && raw.trim().startsWith('{')) {
          resolve(JSON.parse(raw));
          return;
        }
      } catch (err) {
        // seguimos intentando
      }

      if (intentos >= maxIntentos) {
        reject(new Error('No se pudo leer data/datos.json desde el iframe.'));
      } else {
        setTimeout(parsear, 120);
      }
    };

    if (iframe.complete) {
      parsear();
    } else {
      iframe.addEventListener('load', parsear, { once: true });
      setTimeout(parsear, 160);
    }
  });
}

function calcularResumen(acciones) {
  const base = {
    total: acciones.length,
    cumplida: 0,
    cumplida_con_objecion: 0,
    en_ejecucion: 0,
    en_ejecucion_con_retraso: 0,
    no_iniciada: 0,
    sin_informacion: 0
  };

  acciones.forEach((accion) => {
    if (base[accion.estado_general] !== undefined) base[accion.estado_general] += 1;
  });
  return base;
}

function porcentaje(parte, total) {
  return total ? ((parte / total) * 100).toFixed(1) : '0.0';
}

function badgeEstado(estado) {
  const info = estadosMap[estado] || estadosMap.sin_informacion;
  return `<span class="badge badge--${info.clase}">${info.label}</span>`;
}

function colorProgress(accion) {
  const clase = estadosMap[accion.estado_general]?.clase || 'neutral';
  return `progress progress--${clase}`;
}

function renderMeta(meta) {
  $('#titulo-principal').textContent = meta.titulo;
  $('#subtitulo-principal').textContent = meta.subtitulo;
  $('#meta-corte').textContent = `Corte: ${meta.corte}`;
  $('#meta-fuente').textContent = `Fuente: ${meta.fuente}`;
  $('#meta-total').textContent = `${meta.total_acciones} acciones`;

  $('#nota-metodologica').innerHTML = `
    <strong>Nota metodológica</strong>
    <ul>
      ${meta.nota_metodologica.map((item) => `<li>${escapeHtml(item)}</li>`).join('')}
    </ul>
  `;
}

function renderKpis(acciones) {
  const resumen = calcularResumen(acciones);
  const total = resumen.total || 1;
  $('#resumen-kpis').innerHTML = resumenConfig.map((cfg) => {
    const valor = cfg.key === 'total' ? resumen.total : resumen[cfg.key];
    const sub = cfg.key === 'total' ? '100%' : `${porcentaje(valor, total)}%`;
    return `
      <article class="kpi kpi--${cfg.clase}">
        <div class="kpi__titulo">${cfg.titulo}</div>
        <div class="kpi__valor">${valor}</div>
        <div class="kpi__sub">${sub}</div>
      </article>
    `;
  }).join('');
}

function poblarFiltros(acciones) {
  const selectEstado = $('#filtro-estado');
  const selectEntidad = $('#filtro-entidad');

  selectEstado.innerHTML = ['<option value="all">Todos</option>']
    .concat(Object.entries(estadosMap).map(([key, value]) => `<option value="${key}">${value.label}</option>`))
    .join('');

  const entidades = [...new Set(acciones.map((a) => a.entidad_principal).filter(Boolean))].sort((a, b) => a.localeCompare(b));
  selectEntidad.innerHTML = ['<option value="all">Todas</option>']
    .concat(entidades.map((entidad) => `<option value="${escapeHtml(entidad)}">${escapeHtml(entidad)}</option>`))
    .join('');

  $('#filtro-busqueda').addEventListener('input', (e) => {
    state.filtros.busqueda = e.target.value;
    aplicarFiltros();
  });
  selectEstado.addEventListener('change', (e) => {
    state.filtros.estado = e.target.value;
    aplicarFiltros();
  });
  selectEntidad.addEventListener('change', (e) => {
    state.filtros.entidad = e.target.value;
    aplicarFiltros();
  });
  $('#filtro-objecion').addEventListener('change', (e) => {
    state.filtros.objecion = e.target.value;
    aplicarFiltros();
  });
  $('#btn-limpiar').addEventListener('click', () => {
    state.filtros = { busqueda: '', estado: 'all', entidad: 'all', objecion: 'all' };
    $('#filtro-busqueda').value = '';
    selectEstado.value = 'all';
    selectEntidad.value = 'all';
    $('#filtro-objecion').value = 'all';
    aplicarFiltros();
  });
  $('#btn-imprimir').addEventListener('click', () => window.print());
}

function aplicarFiltros() {
  const { acciones } = state.datos;
  const { busqueda, estado, entidad, objecion } = state.filtros;
  const q = normalizar(busqueda);

  state.accionesFiltradas = acciones.filter((accion) => {
    const textoCompleto = normalizar([
      accion.titulo,
      accion.accion_macro,
      accion.condicion_tecnica,
      accion.indicador,
      accion.responsable,
      accion.corresponsable,
      accion.entidad_principal,
      accion.objecion
    ].join(' | '));

    const matchBusqueda = !q || textoCompleto.includes(q);
    const matchEstado = estado === 'all' || accion.estado_general === estado;
    const matchEntidad = entidad === 'all' || accion.entidad_principal === entidad;
    const matchObj = objecion === 'all'
      || (objecion === 'con' && accion.objecion_flag)
      || (objecion === 'sin' && !accion.objecion_flag);

    return matchBusqueda && matchEstado && matchEntidad && matchObj;
  });

  renderEstadoFiltros();
  renderTabla(state.accionesFiltradas);
}

function renderEstadoFiltros() {
  const total = state.datos.acciones.length;
  const visibles = state.accionesFiltradas.length;
  const f = state.filtros;
  const trozos = [];
  if (f.busqueda) trozos.push(`búsqueda: “${escapeHtml(f.busqueda)}”`);
  if (f.estado !== 'all') trozos.push(`estado: ${estadosMap[f.estado].label}`);
  if (f.entidad !== 'all') trozos.push(`entidad: ${escapeHtml(f.entidad)}`);
  if (f.objecion === 'con') trozos.push('solo con objeción');
  if (f.objecion === 'sin') trozos.push('solo sin objeción');

  $('#estado-filtros').innerHTML = trozos.length
    ? `<strong>${visibles}</strong> de <strong>${total}</strong> acciones visibles · ${trozos.join(' · ')}`
    : `<strong>${total}</strong> acciones visibles · sin filtros activos`;
}

function renderSemaforo(acciones) {
  const resumen = calcularResumen(acciones);
  const total = acciones.length || 1;
  const data = [
    {
      titulo: 'Verde',
      cuenta: resumen.cumplida + resumen.cumplida_con_objecion,
      clase: 'ok',
      texto: 'Acciones reportadas como cumplidas. Incluye las que tienen objeciones sobre calidad o soporte.',
      chips: [
        `Cumplidas: ${resumen.cumplida}`,
        `Cumplidas con objeción: ${resumen.cumplida_con_objecion}`,
        `${porcentaje(resumen.cumplida + resumen.cumplida_con_objecion, total)}% del total`
      ]
    },
    {
      titulo: 'Amarillo',
      cuenta: resumen.en_ejecucion + resumen.en_ejecucion_con_retraso,
      clase: 'warn',
      texto: 'Acciones aún abiertas. Se distinguen las que siguen en tiempo y las que presentan retraso frente a la fecha fijada.',
      chips: [
        `En ejecución: ${resumen.en_ejecucion}`,
        `Con retraso: ${resumen.en_ejecucion_con_retraso}`,
        `${porcentaje(resumen.en_ejecucion + resumen.en_ejecucion_con_retraso, total)}% del total`
      ]
    },
    {
      titulo: 'Rojo',
      cuenta: resumen.no_iniciada + resumen.sin_informacion,
      clase: 'bad',
      texto: 'Acciones sin inicio real o sin información disponible, por lo que requieren gestión prioritaria.',
      chips: [
        `No iniciadas: ${resumen.no_iniciada}`,
        `Sin información: ${resumen.sin_informacion}`,
        `${porcentaje(resumen.no_iniciada + resumen.sin_informacion, total)}% del total`
      ]
    }
  ];

  $('#semaforo-contenido').innerHTML = data.map((col) => `
    <article class="semaforo-col">
      <div class="semaforo-col__head" style="background:${colorSemaforo(col.clase)}">
        <h3>${col.titulo}</h3>
        <span>${col.cuenta}</span>
      </div>
      <div class="semaforo-col__body">
        <p class="semaforo-col__texto">${col.texto}</p>
        <div class="chips">
          ${col.chips.map((chip) => `<span class="chip chip--${col.clase}">${chip}</span>`).join('')}
        </div>
      </div>
    </article>
  `).join('');
}

function colorSemaforo(clase) {
  if (clase === 'ok') return 'linear-gradient(135deg, #187b45, #28a35e)';
  if (clase === 'warn') return 'linear-gradient(135deg, #b97700, #e0a100)';
  return 'linear-gradient(135deg, #b62222, #d54141)';
}

function renderTabla(acciones) {
  const tbody = $('#tabla-acciones');
  if (!acciones.length) {
    tbody.innerHTML = `<tr><td colspan="9">No hay acciones que coincidan con los filtros aplicados.</td></tr>`;
    return;
  }

  tbody.innerHTML = acciones.map((accion) => {
    const est = estadosMap[accion.estado_general] || estadosMap.sin_informacion;
    const nota = accion.objecion || accion.inconsistencias[0] || 'Sin observaciones reportadas';
    const progreso = accion.progreso_visual;
    const width = progreso === null ? 6 : Math.max(6, Math.min(progreso, 100));

    return `
      <tr>
        <td class="td-num">${accion.id}</td>
        <td class="td-accion">
          <strong>${escapeHtml(accion.titulo)}</strong>
          <small>${escapeHtml(accion.condicion_tecnica || accion.accion_macro || '')}</small>
        </td>
        <td>${escapeHtml(accion.entidad_principal || '—')}</td>
        <td>${badgeEstado(accion.estado_general)}</td>
        <td>
          <div class="${colorProgress(accion)}"><span style="width:${width}%"></span></div>
          <strong>${pct(progreso)}</strong>
        </td>
        <td>${year(accion.fecha_cumplimiento_fijada)}</td>
        <td>${year(accion.fecha_real_inicio)}</td>
        <td>${year(accion.fecha_real_cumplimiento)}</td>
        <td class="td-nota">
          <small>${escapeHtml(nota)}</small>
          <div class="card__chips" style="margin-top:8px;">
            ${accion.cumplida_tardia ? '<span class="chip chip--warn2">Cumplida tarde</span>' : ''}
            ${accion.retrasada ? '<span class="chip chip--warn2">Retrasada</span>' : ''}
            ${accion.objecion_flag ? '<span class="chip chip--violet">Con objeción</span>' : ''}
            ${accion.inconsistencias.length ? '<span class="chip chip--bad">Inconsistencia</span>' : ''}
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

function renderRetrasos(acciones) {
  const retrasadas = acciones
    .filter((a) => a.retrasada)
    .sort((a, b) => (a.fecha_cumplimiento_fijada || 9999) - (b.fecha_cumplimiento_fijada || 9999));

  const wrap = $('#tabla-retrasos');
  if (!retrasadas.length) {
    wrap.innerHTML = '<p>No hay acciones retrasadas registradas.</p>';
    return;
  }

  wrap.innerHTML = `<div class="cards-list">${retrasadas.map((accion) => {
    const retraso = accion.fecha_cumplimiento_fijada ? 2026 - accion.fecha_cumplimiento_fijada : '—';
    return `
      <article class="retraso-card">
        <h3 class="card__titulo">Acción ${accion.id} · ${escapeHtml(accion.titulo)}</h3>
        <div class="card__meta">
          <span class="chip chip--warn2">Fijada: ${year(accion.fecha_cumplimiento_fijada)}</span>
          <span class="chip chip--warn2">Retraso estimado: ${typeof retraso === 'number' ? `${retraso} año(s)` : retraso}</span>
          <span class="chip chip--warn">Avance: ${pct(accion.progreso_visual)}</span>
        </div>
        <p><strong>Entidad:</strong> ${escapeHtml(accion.entidad_principal)}</p>
        <p>${escapeHtml(accion.condicion_tecnica || accion.accion_macro || '')}</p>
      </article>
    `;
  }).join('')}</div>`;
}

function renderInconsistencias(acciones) {
  const inconsistentes = acciones.filter((a) => a.inconsistencias.length);
  const wrap = $('#lista-inconsistencias');
  if (!inconsistentes.length) {
    wrap.innerHTML = '<p>No se identificaron inconsistencias de datos.</p>';
    return;
  }

  wrap.innerHTML = `<div class="cards-list">${inconsistentes.map((accion) => `
    <article class="inconsistencia-card">
      <h3 class="card__titulo">Acción ${accion.id} · ${escapeHtml(accion.titulo)}</h3>
      <div class="card__chips">
        ${badgeEstado(accion.estado_general)}
        <span class="chip chip--bad">${accion.inconsistencias.length} hallazgo(s)</span>
      </div>
      <p style="margin-top:10px">${accion.inconsistencias.map((i) => `• ${escapeHtml(i)}`).join('<br>')}</p>
    </article>
  `).join('')}</div>`;
}

function resumirEntidades(acciones) {
  const map = new Map();
  acciones.forEach((accion) => {
    const key = accion.entidad_principal || 'Sin entidad definida';
    if (!map.has(key)) {
      map.set(key, {
        entidad: key,
        total: 0,
        cumplidas: 0,
        objeciones: 0,
        retrasadas: 0,
        noIniciadas: 0,
        sumaProgreso: 0,
        progresoContable: 0,
        acciones: []
      });
    }
    const item = map.get(key);
    item.total += 1;
    item.acciones.push(accion.id);
    if (accion.estado_general === 'cumplida' || accion.estado_general === 'cumplida_con_objecion') item.cumplidas += 1;
    if (accion.objecion_flag) item.objeciones += 1;
    if (accion.retrasada) item.retrasadas += 1;
    if (accion.estado_general === 'no_iniciada') item.noIniciadas += 1;
    if (accion.progreso_visual !== null && accion.progreso_visual !== undefined) {
      item.sumaProgreso += accion.progreso_visual;
      item.progresoContable += 1;
    }
  });

  return [...map.values()]
    .map((item) => ({
      ...item,
      avancePromedio: item.progresoContable ? Math.round(item.sumaProgreso / item.progresoContable) : 0
    }))
    .sort((a, b) => b.total - a.total || a.entidad.localeCompare(b.entidad));
}

function renderEntidades(acciones) {
  const entidades = resumirEntidades(acciones);
  $('#entidades-grid').innerHTML = entidades.map((ent) => `
    <article class="entidad-card">
      <h3>${escapeHtml(ent.entidad)}</h3>
      <div class="card__chips">
        <span class="chip chip--neutral">Acciones: ${ent.total}</span>
        <span class="chip chip--ok">Cumplidas: ${ent.cumplidas}</span>
        <span class="chip chip--violet">Objeciones: ${ent.objeciones}</span>
        <span class="chip chip--warn2">Retrasos: ${ent.retrasadas}</span>
        <span class="chip chip--bad">No iniciadas: ${ent.noIniciadas}</span>
      </div>
      <div class="mini-barra"><span style="width:${ent.avancePromedio}%"></span></div>
      <p><strong>Avance promedio estimado:</strong> ${ent.avancePromedio}%</p>
      <p><strong>Acciones:</strong> ${ent.acciones.join(', ')}</p>
    </article>
  `).join('');
}

function renderObjeciones(acciones) {
  const items = acciones.filter((a) => a.objecion_flag);
  const wrap = $('#objeciones-lista');
  if (!items.length) {
    wrap.innerHTML = '<p>No hay objeciones registradas.</p>';
    return;
  }
  wrap.innerHTML = items.map((accion) => `
    <article class="objecion-card">
      <h3>Acción ${accion.id} · ${escapeHtml(accion.titulo)}</h3>
      <div class="card__chips">
        <span class="chip chip--violet">${escapeHtml(accion.entidad_principal)}</span>
        <span class="chip chip--warn">Avance: ${pct(accion.progreso_visual)}</span>
      </div>
      <p style="margin-top:10px"><strong>Objeción:</strong> ${escapeHtml(accion.objecion)}</p>
    </article>
  `).join('');
}

function renderRecomendaciones(recomendaciones) {
  $('#recomendaciones').innerHTML = recomendaciones.map((rec) => `
    <article class="recomendacion-card recomendacion-card--${rec.prioridad}">
      <h3>${escapeHtml(rec.titulo)}</h3>
      <div class="card__chips">
        <span class="chip chip--${rec.prioridad === 'alta' ? 'bad' : rec.prioridad === 'media' ? 'warn' : 'ok'}">Prioridad ${escapeHtml(rec.prioridad)}</span>
      </div>
      <ul>
        ${rec.items.map((item) => `<li>${escapeHtml(item)}</li>`).join('')}
      </ul>
    </article>
  `).join('');
}

function mostrarApp() {
  $('#estado-carga').classList.add('oculto');
  $('#estado-error').classList.add('oculto');
  $('#contenido-app').classList.remove('oculto');
}

function mostrarError(message) {
  $('#estado-carga').classList.add('oculto');
  $('#contenido-app').classList.add('oculto');
  $('#estado-error').classList.remove('oculto');
  $('#detalle-error').textContent = message;
}

async function init() {
  try {
    const datos = await loadData();
    state.datos = datos;
    state.accionesFiltradas = [...datos.acciones];

    renderMeta(datos.meta);
    renderKpis(datos.acciones);
    poblarFiltros(datos.acciones);
    renderSemaforo(datos.acciones);
    renderRetrasos(datos.acciones);
    renderInconsistencias(datos.acciones);
    renderEntidades(datos.acciones);
    renderObjeciones(datos.acciones);
    renderRecomendaciones(datos.recomendaciones || []);
    aplicarFiltros();
    mostrarApp();
  } catch (error) {
    console.error(error);
    mostrarError(error.message || String(error));
  }
}

document.addEventListener('DOMContentLoaded', init);
