# SEMAFORO-ENMA

Proyecto web estático listo para publicar en **GitHub Pages**.

## Estructura

```text
SEMAFORO-ENMA/
├── index.html
├── css/
│   └── estilos.css
├── js/
│   └── app.js
├── data/
│   └── datos.json
├── assets/
└── README.md
```

## Cómo subir el proyecto a GitHub

1. Cree un repositorio nuevo en GitHub, por ejemplo: `semaforo-enma`.
2. Suba el contenido de esta carpeta **SEMAFORO-ENMA** a la raíz del repositorio.
3. Confirme que `index.html` quede en la raíz del repositorio.

Puede hacerlo arrastrando los archivos al repositorio en GitHub o usando Git desde su computador.

## Cómo activar GitHub Pages

1. Abra el repositorio en GitHub.
2. Vaya a **Settings** > **Pages**.
3. En **Build and deployment**, seleccione:
   - **Source:** Deploy from a branch
   - **Branch:** `main` (o `master`)
   - **Folder:** `/root`
4. Guarde los cambios.
5. Espere unos segundos a que GitHub publique el sitio.

## URL pública esperada

La URL pública normalmente será:

```text
https://SU-USUARIO.github.io/NOMBRE-DEL-REPOSITORIO/
```

Ejemplo:

```text
https://usuario.github.io/semaforo-enma/
```

## Notas técnicas

- El proyecto usa solo **HTML, CSS y JavaScript puro**.
- No requiere backend, Node, npm, React ni servidor especial.
- Todas las rutas son **relativas**.
- El visor intenta cargar `data/datos.json` por `fetch()` y, si el navegador bloquea eso al abrir localmente `index.html`, usa un mecanismo de respaldo para seguir funcionando también en modo local.
